package christmasPastryShop.repositories.interfaces;

import christmasPastryShop.entities.booths.interfaces.Booth;

import java.util.*;

public class BoothRepositoryImpl implements BoothRepository{

    private Collection<Booth> models;

    public BoothRepositoryImpl() {
        this.models = new ArrayList<>();
    }

    @Override
    public Object getByNumber(int number) {

        for (Booth model : models) {
            if (model.getBoothNumber()==number){
                return model;
            }
        }
        for (Booth model : models) {
            if (model.getBoothNumber()==number){
                return model;
            }
        }
        return null;
        //return models.stream().filter(b -> b.getBoothNumber()==number ).findAny();

    }

    @Override
    public Collection getAll() {
        return Collections.unmodifiableCollection(models);
    }

    @Override
    public void add(Object o) {

        models.add((Booth) o);
    }
}
