package goldDigger.models.discoverer;

import java.util.*;

public class Anthropologist extends BaseDiscoverer{
    private static final double initial_energy = 40;

    public Anthropologist(String name) {
        super(name, initial_energy);
    }

}
