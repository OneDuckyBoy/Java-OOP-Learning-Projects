package goldDigger.models.discoverer;

import java.util.*;

public class Archaeologist extends BaseDiscoverer{
    private static final double initial_energy = 60;
    public Archaeologist(String name) {
        super(name, initial_energy);
    }


}
