package goldDigger.repositories;

import goldDigger.models.discoverer.Discoverer;

import java.util.*;

public class DiscovererRepository implements Repository{

    private Collection<Discoverer>discoverers;//todo

    public DiscovererRepository() {
        this.discoverers = new ArrayList<>();//LinkedHashMap<>();
    }

    @Override
    public Collection getCollection() {
        return null;
    }

    @Override
    public void add(Object entity) {

    }

    @Override
    public boolean remove(Object entity) {
        return false;
    }

    @Override
    public Object byName(String name) {
        return null;
    }
}
